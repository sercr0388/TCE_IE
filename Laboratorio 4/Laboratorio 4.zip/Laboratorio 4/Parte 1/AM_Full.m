% Modulaci�n AM DSB y DSB Multitono
% Instituto Tecnologico de Costa Rica (www.tec.ac.cr)
% Escuela de Ingenier�a Electr�nica
% Prof: Ing. Sergio Arriola-Valverde. M. Sc (sarriola@tec.ac.cr)
% Curso: EL-5522 Taller de Comunicaciones El�ctricas
% Este Script esta estructurado en Matlab 
% Prop�sito General: Modulaci�n AM DSB y DSB Multitono
% Entradas: Cantidad de tonos, indice de modulaci�n y delta de frecuencia.
% Tomado y adapdato de: https://www.mathworks.com/matlabcentral/fileexchange/8732-amplitude-modulation
% Esto material son para uso unicamente didactico y academico

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Limpio la terminal y variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;
close all;
clear all;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Definicion de parametros
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N = 32768;   %Puntos de la FFT N>fc evitar aliasing
fs = 131072; % Frecuencia de muestreo
t = (0:N)/fs;
fc  = 30000;  % Frecuencia de portadora
Ec  = 1;    % Amplitud de la portadora 
desviacion = 1000; % Desviacion de los tonos
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tonos = input('Digite la cantidad de tonos que desea visualizar: ');


if (tonos == 0)
   disp('Modulacion con un 1 tono')
   indice_modulacion = input('Digite el indice de modulaci�n: ');
   
   if (0>indice_modulacion||indice_modulacion>3)
    error('El indice de moludacion deber estar entre 1 y 3'); % Funcion de error
   end
   A = Ec +(Ec*indice_modulacion)*(cos(2*pi*(desviacion)*t));
   A_1 = (Ec*indice_modulacion)*(cos(2*pi*(desviacion)*t));
end

if (tonos ~= 0)
 
    indice_modulacion = input('Digite el indice de modulaci�n: ');
    matriz_desviacion = zeros(1,tonos);
    if (0>indice_modulacion||indice_modulacion>3)
    error('El indice de moludacion deber estar entre 1 y 3'); % Funcion de error
    end
    for counter = 1:tonos
        multiplo_desviacion = ((counter)*desviacion);
        matriz_desviacion(1,counter) = multiplo_desviacion;
        if (counter == 1)
            A = Ec +(Ec*indice_modulacion)*(cos(2*pi*(matriz_desviacion(1,counter))*t));
            A_1 = (Ec*indice_modulacion)*(cos(2*pi*(matriz_desviacion(1,counter))*t));
        end
        if(counter ~= 1)
            A(1,:) = A(1,:)+(Ec*indice_modulacion)*(cos(2*pi*(matriz_desviacion(1,counter))*t));
            A_1(1,:) = A_1(1,:) + (Ec*indice_modulacion)*(cos(2*pi*(matriz_desviacion(1,counter))*t));
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Doble Banda Lateral con Portadora
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
m = A.*[cos(2*pi*fc*t)];
Mf = 2/N*abs(fft(m,N));
Mf = 10*log(Mf/1e-3);
f = fs * (0 : (N/2)-1) / N;    %Solamente se toma el caso positivo para representacion
close all;
figure('Name','Modulacion AM-DSB');
subplot(2,1,1); % Grafico en el dominio del tiempo
plot(t(1:N/64),m(1:N/64));
title('Representaci�n en el Dominio Temporal');
xlabel('Tiempo'); ylabel('Se�al Modulada');
subplot(2,1,2); % Grafico en el dominio de la frecuencia
plot(f(1:end),Mf(1:N/2));
title('Representaci�n en el Dominio de la Frecuencia');
xlabel('Frequencia (Hz)'); ylabel('Magnitud Espectral (dBm)');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Doble Banda Lateral sin Portadora
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
m  = A_1.*[cos(2*pi*fc*t)];                                                  
Mf = 2/N*abs(fft(m,N));
Mf = 10*log(Mf/1e-3);
figure('Name','Modulacion AM DSB SC');
subplot(2,1,1); % Grafico en el dominio del tiempo
plot(t(1:N/64),m(1:N/64));
title('Representaci�n en el Dominio Temporal');
xlabel('Tiempo'); ylabel('Se�al Modulada');
subplot(2,1,2); % Grafico en el dominio de la frecuencia
plot(f(1:end),Mf(1:N/2));
title('Representaci�n en el Dominio de la Frecuencia');
xlabel('Frequencia (Hz)'); ylabel('Magnitud Espectral (dBm)');

%<<<<<<<<<<<<<<<<<<<<<<<<<FIN>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

