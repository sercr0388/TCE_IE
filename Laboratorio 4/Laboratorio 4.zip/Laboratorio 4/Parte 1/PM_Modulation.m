% Modulaci�n PM Multitono
% Instituto Tecnologico de Costa Rica (www.tec.ac.cr)
% Escuela de Ingenier�a Electr�nica
% Prof: Ing. Sergio Arriola-Valverde. M. Sc (sarriola@tec.ac.cr)
% Curso: EL-5522 Taller de Comunicaciones El�ctricas
% Este Script esta estructurado en Matlab 
% Prop�sito General: Modulaci�n PM Multitono
% Entradas: Cantidad de tonos y desviacion de fase
% Tomado y adapdato de: https://www.mathworks.com/matlabcentral/fileexchange/8732-amplitude-modulation
% 
% Esto material son para uso unicamente didactico y academico

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Limpio la terminal y variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;
close all;
clear all;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Definicion de parametros
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N = 32768;   %Puntos de la FFT N>fc evitar aliasing
fs = 131072; % Frecuencia de muestreo
t = (0:N)/fs;
fc  = 30000;  % Frecuencia de portadora
Ec  = 1;    % Amplitud de la portadora 
desviacion = 200; % Desviacion de los tonos
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tonos = input('Digite la cantidad de tonos que desea visualizar: ');
desviacion_fase = input('Digite la desviacion de fase en grados: ');
desviacion_fase = desviacion_fase*(pi/180);


if (tonos == 0)
   disp('Modulacion con un 1 tono')
   m = cos(2*pi*fc*t + desviacion_fase*(sin(2*pi*(desviacion)*t)));
   
end

if (tonos ~= 0)
    matriz_desviacion = zeros(1,tonos);
    for counter = 1:tonos
        multiplo_desviacion = ((counter)*desviacion);
        matriz_desviacion(1,counter) = multiplo_desviacion;
        m = cos(2*pi*fc*t + desviacion_fase*(sin(2*pi*(matriz_desviacion(1,counter))*t)));
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PM 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Mf = 2/N*abs(fft(m,N));
Mf = 10*log(Mf/1e-3);
f = fs * (0 : (N/2)-1) / N;    %Solamente se toma el caso positivo para representacion
close all;
figure('Name','Modulacion PM');
subplot(2,1,1); % Grafico en el dominio del tiempo
plot(t(1:N/64),m(1:N/64));
title('Se�al Temporal');
xlabel('Time'); ylabel('Se�al Modulada');
subplot(2,1,2); % Grafico en el dominio de la frecuencia
plot(f(1:end),Mf(1:N/2));
title('Representaci�n en el dominio de la Frecuencia');
xlabel('Frequencia (Hz)'); ylabel('Magnitud');

%<<<<<<<<<<<<<<<<<<<<<<<<<FIN>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

