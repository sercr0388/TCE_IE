% Efecto de ISI mediante diagramas de Ojo
% Instituto Tecnologico de Costa Rica (www.tec.ac.cr)
% Escuela de Ingenier�a Electr�nica
% Prof: Ing. Sergio Arriola-Valverde. M.Sc (sarriola@tec.ac.cr)
% Curso: EL-5522 Taller de Comunicaciones El�ctricas
% Este Script esta estructurado en Matlab 
% Prop�sito General: Efecto de ISI mediante diagramas de Ojo
% Entradas: Orden de Constelacion
% Tomado y adaptado de: https://www.mathworks.com/help/comm/ug/reduce-isi-using-raised-cosine-filtering.html
% Este material es para uso unicamente didactico y academico

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Limpio la terminal y variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;
close all;
clear all;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Adquisicion de variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Modulacion QAM M-ary')
M = input('Digite el orden de la modulaci�n: '); % Orden de modulacion

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Configuracion del filtro Raised Cosine
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

txfilter = comm.RaisedCosineTransmitFilter;
rxfilter = comm.RaisedCosineReceiveFilter;

hpa = comm.MemorylessNonlinearity('Method','Saleh model', ...
    'InputScaling',-10,'OutputScaling',0); % Introduccion de no linealidades

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modulacion QAM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x = randi([0 M-1],1000,1); % Datos aleatorios
modSig = qammod(x,M,'UnitAveragePower',true); % Modulacion QAM

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Diagrama de Ojo
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%16

eyediagram(modSig,2) % Diagrama de Ojo I-Q Modulacion
txSigNoFilt = hpa(modSig);
eyediagram(txSigNoFilt,2);  % Con hpa no linealidades
filteredSig = txfilter(modSig); % Transmision filtrada con RRC
release(hpa)
txSig = hpa(filteredSig);
rxSig = rxfilter(txSig); % Se�al del receptor
eyediagram(rxSig,2)

%>>>>>>>>>>>>>>>>>>>>>>>>>> FIN  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>%










