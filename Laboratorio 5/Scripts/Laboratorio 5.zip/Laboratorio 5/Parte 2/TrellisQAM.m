% Efecto Rate 2/3 Convolutional Code in AWGN
% Instituto Tecnologico de Costa Rica (www.tec.ac.cr)
% Escuela de Ingenier�a Electr�nica
% Prof: Ing. Sergio Arriola-Valverde. M.Sc (sarriola@tec.ac.cr)
% Curso: EL-5522 Taller de Comunicaciones El�ctricas
% Este Script esta estructurado en Matlab 
% Prop�sito General: Efecto Rate 2/3 Convolutional Code in AWGN
% Entradas: Orden de Constelacion
% Tomado y adaptado de: Ejemplo de Matlab Communications Toolbox
% Este material es para uso unicamente didactico y academico
%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Limpio la terminal y variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;
close all;
clear all;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Adquisicion de variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Modulacion QAM M-ary')
M = input('Digite el orden de la modulaci�n: '); % Orden de modulacion
k = log2(M);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Creacion de rate 2/3 convolutional
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
trellis = poly2trellis([5 4],[23 35 0; 0 5 13]); 
traceBack = 16;
codeRate = 2/3;

% Codificacion convolucional equivalente a Viterbi
convEncoder = comm.ConvolutionalEncoder('TrellisStructure',trellis);
vitDecoder = comm.ViterbiDecoder('TrellisStructure',trellis, ...
    'InputFormat','Hard','TracebackDepth',traceBack);
% Modulacion QAM
qamModulator = comm.RectangularQAMModulator('BitInput',true,'NormalizationMethod','Average power');
qamDemodulator = comm.RectangularQAMDemodulator('BitOutput',true,'NormalizationMethod','Average power');
% Creacion de tasa de error 
errorRate = comm.ErrorRate('ReceiveDelay',2*traceBack);
% Se declara el vector de error
ebnoVec = 0:2:10;
errorStats = zeros(length(ebnoVec),3);
%%
% Simulate realiza los siguiente pasos

% Generaci�n de datos binarios.
% Codificacion utilizando un codigo rate 2/3 convolutional
% Se modulan los datos codificados.
% Se agrega ruido gausiano
% Se demodula la se�al.
% Se decodifica la se�al mediante Viterbi.
% Se calculan errores estadisticos.


for m = 1:length(ebnoVec)
    snr = ebnoVec(m) + 10*log10(k*codeRate);
    %%
    while errorStats(m,2) <= 100 && errorStats(m,3) <= 1e7
        dataIn = randi([0 1],10000,1);
        dataEnc = convEncoder(dataIn);
        txSig = qamModulator(dataEnc);
        rxSig = awgn(txSig,snr);
        demodSig = qamDemodulator(rxSig);
        dataOut = vitDecoder(demodSig);
        errorStats(m,:) = errorRate(dataIn,dataOut);
    end
    reset(errorRate)
end
%%
% Calculo de BER vs. Eb/No de manera teorica
berUncoded = berawgn(ebnoVec','qam',M);
%%
% Se grafica los parametros
semilogy(ebnoVec,[errorStats(:,1) berUncoded])
grid
legend('Codificado','No Codificado')
xlabel('Eb/No (dB)')
ylabel('Bit Error Rate')
%%

%>>>>>>>>>>>>>>>>>>>>>>>>>> FIN  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>%