% Graficos Parametros S para Simulaciones AWR
% Instituto Tecnologico de Costa Rica (www.tec.ac.cr)
% Escuela de Ingenier�a Electr�nica
% Prof: Ing. Sergio Arriola-Valverde. M. Sc (sarriola@tec.ac.cr)
% Curso: EL-5522 Taller de Comunicaciones El�ctricas
% Este Script esta estructurado en Matlab 
% Prop�sito General: Grafico de Parametros S contra simulacion de AWR
% Entradas: Touchstone files s2p
% Este material son para uso unicamente didactico y academico

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Limpio la terminal y variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc;
close all;
clear all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Busqueda de archivos snp
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[Nombre_Arch, Dir_Arch] = uigetfile( ...
{'*.s1p;*.s2p;*.s3p;*.s4p;*.s5p;*.s6p;*.s7p;*.s8p;*.s9p;*.s10p;*.s12p;*.ts',...
 'Touchstone Files (*.snp,*.ts)';
   '*.snp', 'Version 1.0 (*.s1p;*.s2p;*.s3p;*.s4p;*.s5p;*.s6p;*.s7p;*.s8p;*.s9p;*.s10p;*.s12p)'; ...
   '*.ts', 'Version 2.0 (*.ts)'
   '*.*',  'All Files (*.*)'}, ...
   'Select a file');
data = read(rfdata.data,Nombre_Arch);
frecs = data.Freq;
frecs=frecs'; % Vector de frecuencuas
ZF = extract(data,'S_PARAMETERS'); % Matriz de parametros

[Nombre_Arch_1, Dir_Arch_1] = uigetfile( ...
{'*.s1p;*.s2p;*.s3p;*.s4p;*.s5p;*.s6p;*.s7p;*.s8p;*.s9p;*.s10p;*.s12p;*.ts',...
 'Touchstone Files (*.snp,*.ts)';
   '*.snp', 'Version 1.0 (*.s1p;*.s2p;*.s3p;*.s4p;*.s5p;*.s6p;*.s7p;*.s8p;*.s9p;*.s10p;*.s12p)'; ...
   '*.ts', 'Version 2.0 (*.ts)'
   '*.*',  'All Files (*.*)'}, ...
   'Select a file');
data_1 = read(rfdata.data,Nombre_Arch_1);
frecs_1 = data.Freq;
frecs_1=frecs_1'; % Vector de frecuencuas
ZF_1 = extract(data_1,'S_PARAMETERS'); % Matriz de parametros


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Grafica de parametros S
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
set(gca,'FontSize',12);
dummy=squeeze(ZF(1,1,:));
plot(frecs./1e9,20*log10((abs(dummy))),'Color','r','LineWidth',3);
hold on;
grid on;

dummy=squeeze(ZF_1(1,1,2:end));
plot(frecs./1e9,20*log10((abs(dummy))),'Color','b','LineWidth',3);

dummy=squeeze(ZF(2,2,:));
plot(frecs./1e9,20*log10((abs(dummy))),'Color','y','LineWidth',3);

dummy=squeeze(ZF_1(2,2,2:end));
plot(frecs./1e9,20*log10((abs(dummy))),'Color','k','LineWidth',3);

ax = gca;
ax.FontSize = 13;
legend({'S_{11} Medido','S_{11} AWR','S_{22} Medido','S_{22} AWR'},'Location','southeast')
xlabel('Frecuencia [GHz]');
ylabel('Magnitud  [dB]');
title('Reflexiones');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(2)
set(gca,'FontSize',12);
dummy=squeeze(ZF(1,2,:));
plot(frecs./1e9,20*log10((abs(dummy))),'Color','r','LineWidth',3);
hold on;
grid on;

dummy=squeeze(ZF_1(1,2,2:end));
plot(frecs./1e9,20*log10((abs(dummy))),'Color','b','LineWidth',3);

dummy=squeeze(ZF(2,1,:));
plot(frecs./1e9,20*log10((abs(dummy))),'Color','y','LineWidth',3);

dummy=squeeze(ZF_1(2,1,2:end));
plot(frecs./1e9,20*log10((abs(dummy))),'Color','k','LineWidth',3);

ax = gca;
ax.FontSize = 13;
legend({'S_{12} Medido','S_{12} AWR','S_{21} Medido','S_{21} AWR'},'Location','southeast')
xlabel('Frecuencia [GHz]');
ylabel('Magnitud  [dB]');
title('Transmisiones');


