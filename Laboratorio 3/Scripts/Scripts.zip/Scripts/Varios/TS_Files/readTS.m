function [ZF,frecs,name,parameter] = readTS()
% Read a Touchstone file and generate the ZF matrix and frequency vector.
% Parameters:
%   OUT
%   ZF            tridimensional matrix that contains the respective S-parameters, for each frequency
%                 [numPorts x numPorts x indexFrequency]
%   frecs         vector or frequencies
%   name          name of the file to read
%   parameter     Type of S-Parameter
%
% This function allows the read of text files with extension: (*.snp , *.ts)%
% and generates the S-paramaters and the frequency vector.
% Written by Jonathan Cede�o on Sep 2014.
%
% Changes: 
% *************************************************************************
frecs = [];
Z=[];
ZF=[];
T=[];
% Opening the file to read
[Nombre_Arch, Dir_Arch] = uigetfile( ...
{'*.s1p;*.s2p;*.s3p;*.s4p;*.s5p;*.s6p;*.s7p;*.s8p;*.s9p;*.ts',...
 'Touchstone Files (*.snp,*.ts)';
   '*.snp', 'Version 1.0 (*.s1p;*.s2p;*.s3p;*.s4p;*.s5p;*.s6p;*.s7p;*.s8p;*.s9p)'; ...
   '*.ts', 'Version 2.0 (*.ts)'
   '*.*',  'All Files (*.*)'}, ...
   'Select a file');
if isequal(Nombre_Arch,0)
   return;
else
% Extracting the complete name of file to read   
   Archivo=fullfile(Dir_Arch, Nombre_Arch);
end
% Opening the file
Dat = fopen(Archivo,'r');
% Counters
n=1;
j=1;
p=1;
v=0;
name = Nombre_Arch;
%Loop for read each line of *.ts or *snp file
while ~feof(Dat)
   % Extracting the ID's file. 
   leer_linea = fgetl(Dat);
   if ~ischar(leer_linea)
       break;
   end   
   C(n)= cellstr(leer_linea);
   a=C(n);
   b=a;
   i=1;
   % Extract for 2 ports models
   
   
   % Compares the beginning of each line for only read the numeric
   % characters
   % Read the Option Line
   if (strcmp(strtok(a),'#') == true)
       while(~cellfun('isempty',b))           
           [c,b] = strtok(a);
           a = b;
           F{i} = c;
           i = i+1;
       end
   end
   % Read all numerical parameters, discriminates the Option Line, Comments
   % and Keywords defined for v2.0
   if ((strcmp(strtok(a),'!')|strcmp(strtok(a),'#')|strcmp(strtok(a),'[Version]')|strcmp(strtok(a),'[Number')|strcmp(strtok(a),'[Number')|strcmp(strtok(a),'[Network')|strcmp(strtok(a),'[End]')) ~= true)%para trabajar con los numericos              
       % Reading the numeric characters from the file
       while(~cellfun('isempty',b))
           [c,b] = strtok(a);
           a = b;
           % Stores each number on the matrix Z
           Z(j,i) = str2double(c);  
           y = size(Z);
           % Stores the frequency vector and order the rest of numbers           
           if (and(cellfun('isempty',b), Z(j,y(2)) ~=0))               
               frecs(p) = Z(j,1);
               for k=1:1:(y(2)-1)                   
                   Z(j,k)=Z(j,k+1);                   
               end               
               p = p+1; % Frequency vector counter
           end           
           i = i+1; % Column counter           
       end
       % Aqui puedo meter la condicion de que si es algo diferente a numerico,
        % no cuente, asi evito usar breaks
       j = j+1; % Row counter
   end   
   n = n+1; % Line Counter   
end
disp(leer_linea);
fclose(Dat);
% Delete last column of zeros
Z(:,y(2)) = [];
p = 1;
% Scale frequency units
switch (char(F{2}))
    case 'HZ'
        frecs = 1*frecs;
    case 'Hz'
        frecs = 1*frecs;
    case 'KHZ'
        frecs = 1e3*frecs;
    case 'KHz'
        frecs = 1e3*frecs;
    case 'MHZ'
        frecs = 1e6*frecs;
    case 'MHz'
        frecs = 1e6*frecs;
    case 'GHZ'
        frecs = 1e9*frecs;
    case 'GHz'
        frecs = 1e9*frecs;
    otherwise
        error('Invalid format of frequency')
end
% Define format
parameter = char(F{3});
switch (char(F{4}))
    case 'RI'
        for j=1:2:(y(2)-1)
            T(:,p) = [;complex(Z(:,j),Z(:,j+1))];   
            p = p + 1;
        end
    case 'MA'
        for j=1:2:(y(2)-1)
            T(:,p) = [;complex(Z(:,j).*cosd(Z(:,j+1)),Z(:,j).*sind(Z(:,j+1)))];   
            p = p + 1;
        end
    case 'DB'
        for j=1:2:(y(2)-1)
            T(:,p) = [;complex((10.^(Z(:,j).*(0.05))).*cosd(Z(:,j+1)),(10.^(Z(:,j).*(0.05))).*sind(Z(:,j+1)))];   
            p = p + 1;
        end
    otherwise
        disp('Invalid format');
end
y=size(T);
p=1;
% Generates the S-parameters matrix
for j=2:(y(2)+1):(y(1)-3)
    ZF(:,:,p)= [T([j:j+(y(2)-1)],:);];
    p=p+1;
end
end
%Normalizacion de par�metros. Ejemplo de *.ts para probar programaci�n
