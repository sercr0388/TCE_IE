function [] = writeTS(V,R,file_name,Zpp,frequencies,parameter,format,formatf, varargin) 
% Write a Zpp matrix to an SnP file.
%
%   WRITESNP(R, file_name, Zpp, frequencies, parameter, format, formatf)
%
%   or
%
%   WRITESNP(R, file_name, Zpp, frequencies, parameter, format, formatf, folder_name)
%
% Parameters:
%   **V         version to store the file(numeric).
%   R           reference resistance (only for the option line).
%   file_name   name of the snp-file without the .snp file ending.
%   Zpp         matrix of impedances of size  [numPorts x numPorts x numFrequencies]
%   frequencies vector of frequencies in Hz
%   parameter   S of Z depending on what values are given in Zpp
%               (only for the option line).
%   format      format to store data in ('MA', 'RI' or 'DB')
%   formatf     format to save frequency in ('Hz', 'GHz', 'MHz' or 'KHz')
%   folder_name name of folder to save snp-file in.
%
% If folder_name is not given, a gui will open to select the folder.
%
%
% Written by Dion Timmermann on 11. Sep 2009, bysic layout based on a
% FORTRAN version of this function, parameter handling based on code by
% Andrzej Stepan from 27.01.2008
%
% Changes: 11. Sep 2009 DT - Improved handling of 2-port matrices and line
%                            breaks for 4-port matrices.
%              Sep 2014 Jonathan Cede�o - Added the possibility to write
%                                         v2.0 files (*.ts)
% *************************************************************************

workDir = pwd();

if nargin == 8
    % defining the folder where the file will be created
    cd(uigetdir);
elseif nargin == 9
    cd(varargin{1});
else
    error('Wrong number of arguments!');
end

%Choose the version
switch (V)
    case 1
        % defining file ending, e.g.: .s2p what means touchstone format for 2 ports
        file_ending = strcat('.s',num2str(size(Zpp, 1)),'p');
        % joining the strings of the file name ans file ending
        file_name = strcat(file_name, file_ending);
        % opening the file for writting
        fHandle = fopen(file_name, 'wt');
        % defining in the first line as a comment that introduces the Option Line
        fprintf(fHandle, '! ######################################');
        fprintf(fHandle, '! Created on %s\n',date());
        % Option Line
        fprintf(fHandle, '%s ', '#', formatf, parameter, format, 'R');
        % adding the reference resistance
        fprintf(fHandle,'%4.2f\n\n', R);
        
    case 2
        % defining file ending: *.ts
        file_ending = strcat('.ts');
        % joining the strings of the file name ans file ending
        file_name = strcat(file_name, file_ending);
        % opening the file for writting
        fHandle = fopen(file_name, 'wt');
        % defining in the first line as a comment that introduces the Option Line
        fprintf(fHandle, '! Touchstone data file \n');
        fprintf(fHandle, '[Version] 2.0 \n');
        % Option Line
        fprintf(fHandle, '%s ', '#', formatf, parameter, format, 'R');
        % adding the reference resistance
        fprintf(fHandle,'%4.2f\n', R);
        fprintf(fHandle, '[Number of Ports] %s\n',num2str(size(Zpp, 1)));    
        fprintf(fHandle, '[Number of Frequencies] %s\n',num2str(size(Zpp, 3)));
        fprintf(fHandle, '[Network Data]');
end

%scale frequency units
formatf=upper(formatf);
switch formatf
    case 'GHZ'
        f_scale=1e9;
    case 'MHZ'
        f_scale=1e6;
    case 'KHZ'
        f_scale=1e3;
    case 'HZ'
        f_scale=1;
    otherwise
        error('not recognized frequency units')
end

%check format

FORMAT_MA = 1;
FORMAT_RI = 2;
FORMAT_DB = 3;

format=upper(format);
switch format
    case 'MA'
        format = FORMAT_MA;
    case 'RI'
        format = FORMAT_RI;
    case 'DB'
        format = FORMAT_DB;
    otherwise
        error('not recognized store data format')
end


numFrequencies  = size(Zpp, 3);%elemento 3 de la matriz Zpp [numports x numports x numFrequencies]
numPorts        = size(Zpp, 1);%idem 1

% check if frequencies are given in ascending order (required by touchstone 
% file format)
for f=2:numFrequencies
    if frequencies(f) <= frequencies(f-1)
        error('frequencies not given in ascending order!');
    end
end

% define the format strings
formatNumber = '%-24.15e';

formatA = '\n\n';
for i=1:9, formatA = [formatA formatNumber]; end

formatB = '\n                        ';
for i=1:8, formatB = [formatB formatNumber]; end
    
for f=1:numFrequencies
    
    ZppCurrentF = Zpp(:, :, f);
    
    % Here we could convert the matrix to s-parameters
    
    % Converte for correct output format (DB MA)
    % This function always prints first the real part, than the imag part.
    % If we want to output magnitude and angle, we simply save the
    % magnitude as real part and angle as imag part.
    switch format
        case FORMAT_RI
            % Do nothing
        case FORMAT_MA
            ZppCurrentF(:, :) = abs(ZppCurrentF(:, :)) + ...
                                1j*rad2deg(angle(ZppCurrentF(:, :)));
        case FORMAT_DB
            ZppCurrentF(:, :) = 20*log10(abs(ZppCurrentF(:, :))) + ...
                                1j*rad2deg(angle(ZppCurrentF(:, :)));
    end
    
    % Handle special case for 2 ports
    if numPorts == 2
        % These ports have to be written to only one line.
        ZppCurrentF = transpose(ZppCurrentF);
        
        fprintf(fHandle,formatA, frequencies(f)/f_scale, ...
            [real(ZppCurrentF(1,1:min(end, 4))) real(ZppCurrentF(2,1:min(end, 4))); ...
             imag(ZppCurrentF(1,1:min(end, 4))) imag(ZppCurrentF(2,1:min(end, 4)))]);
        
        continue;
    end
    
    %fprintf(fHandle, '\n\n#Frequency %d\n', f);

    r=1;
        % For every first row of ports we have to add the frequency
        %fprintf(fHandle, '\n\n#Row %d\n', r);
        
        fprintf(fHandle,formatA, frequencies(f)/f_scale, ...
            [real(ZppCurrentF(r,1:min(end, 4))); imag(ZppCurrentF(r,1:min(end, 4)))]);
        
        % This if ensures there are no lines created which contain no
        % data.
        if numPorts > 4
            % After the first 4 datasets (8 values) we do not repeat the
            % frequency
            fprintf(fHandle, formatB, ...
                [real(ZppCurrentF(r,5:end)); imag(ZppCurrentF(r,5:end))]);
        end

    
    for r=2:numPorts
        % For all other rows of ports we do not need the frequency
        %fprintf(fHandle, '\n#Row %d\n', r);
        
        fprintf(fHandle, formatB, ...
            [real(ZppCurrentF(r,:)); imag(ZppCurrentF(r,:))]);
    end
end
switch (V)
    case 1
        %Do nothing
    case 2
        fprintf(fHandle,'\n\n[End]');
end
fprintf(fHandle, '\n\n');  
fclose(fHandle);
switch (V)
    case 1
        fprintf('SnP file written successfully!\n');
    case 2
        fprintf('TS file written successfully!\n');
end
cd(workDir);

end


        
