function plot_magdb(Matrix,freq,color)

% This function plots the magnitude in dB scale of a parameter against the frequency
% Inputs:
%       Matrix - e.g. SAB(1,1,:)
%       freq -  frequency vector
%       color - of line, e.g. 'r', for red
%
% last modified by terd 05.01.2008
%figure

set(gca,'FontSize',12);
dummy=squeeze(Matrix);
plot(freq./1e9,20*log10((abs(dummy))),'Color',color);

xlabel('frequency [GHz]');
ylabel('S-parameters [dB]');

