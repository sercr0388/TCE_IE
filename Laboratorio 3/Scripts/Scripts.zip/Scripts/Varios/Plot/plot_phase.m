function plot_phase(Matrix,freq,color)

% This function plots the phase of a parameter against the frequency
% Inputs:
%       Matrix - e.g. SAB(1,1,:)
%       freq -  frequency vector
%       color - of line, e.g. 'r', for red
%
% last modified by terd 05.01.2008
%figure

dummy=squeeze(Matrix);
plot(freq./1e9,((angle(dummy))),'Color',color);
set(gca,'FontSize',12);
xlabel('frequency [GHz]');
ylabel('S-parameters phase [rad]');

