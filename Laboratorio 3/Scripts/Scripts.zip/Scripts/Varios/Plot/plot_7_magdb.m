function plot_7_magdb(Matrix,freq,color,Matrix1,freq1,color1,Matrix2,freq2,color2,Matrix3,freq3,color3,Matrix4,freq4,color4,Matrix5,freq5,color5,Matrix6,freq6,color6)

% This function plots the phase of 7 parameters in dB scale against the frequency
% Inputs:
%       Matrix - first parameter e.g. SAB(1,1,:)
%       freq -  first frequency vector
%       color - of first line, e.g. 'r', for red
%       Matrix1 - second parameter e.g. SAB(1,2,:)
%       freq1 -  second frequency vector
%       color1 - of second line, e.g. 'r', for red
%
% last modified by teas on ??.??.2008

figure
set(gca,'FontSize',12);
dummy=squeeze(Matrix);
plot(freq./1e9,20*log10((abs(dummy))),'Color',color,'LineWidth',2.5);
hold on;
grid on;
dummy=squeeze(Matrix1);
plot(freq1./1e9,20*log10((abs(dummy))),'Color',color1,'LineWidth',2.5);
hold on;
grid on;
dummy=squeeze(Matrix2);
plot(freq2./1e9,20*log10((abs(dummy))),'Color',color2,'LineWidth',2.5);
hold on;
grid on;
dummy=squeeze(Matrix3);
plot(freq3./1e9,20*log10((abs(dummy))),'Color',color3,'LineWidth',2.5);
hold on;
grid on;
dummy=squeeze(Matrix4);
plot(freq4./1e9,20*log10((abs(dummy))),'Color',color4,'LineWidth',2.5);
hold on;
grid on;
dummy=squeeze(Matrix5);
plot(freq5./1e9,20*log10((abs(dummy))),'Color',color5,'LineWidth',2.5);
hold on;
grid on;
dummy=squeeze(Matrix6);
plot(freq6./1e9,20*log10((abs(dummy))),'Color',color6,'LineWidth',2.5);

xlabel('frequency [GHz]');
ylabel('S-parameters [dB]');





