function plot_3_phase(Matrix,freq,color,Matrix1,freq1,color1,Matrix2,freq2,color2)

% This function plots the phase of 3 parameters against the frequency
% Inputs:
%       Matrix - first parameter e.g. SAB(1,1,:)
%       freq -  first frequency vector
%       color - of first line, e.g. 'r', for red
%       Matrix1 - second parameter e.g. SAB(1,2,:)
%       freq1 -  second frequency vector
%       color1 - of second line, e.g. 'r', for red
%       Matrix2 - third parameter e.g. SAB(1,2,:)
%       freq2 -  third frequency vector
%       color2 - of third line, e.g. 'r', for red
%
% last modified by terd 05.01.2008

figure
set(gca,'FontSize',12);
dummy=squeeze(Matrix);
plot(freq./1e9,angle(dummy),'Color',color);
hold on;
grid on;
dummy=squeeze(Matrix1);
plot(freq1./1e9,angle(dummy),'Color',color1,'LineWidth',2,'Marker','o');
hold on;
grid on;
dummy=squeeze(Matrix2);
plot(freq2./1e9,angle(dummy),'Color',color2);
xlabel('frequency [GHz]');
ylabel('S-parameter phase [rad]');
hold off;



