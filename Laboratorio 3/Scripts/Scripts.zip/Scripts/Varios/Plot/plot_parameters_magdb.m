function plot_parameters_magdb(Matrix,freq,color)

% This function plots the magnitude in dB scale of all parameters against
% the frequency, in a subplot window.
% Inputs:
%       Matrix - e.g. SAB
%       freq -  frequency vector
%       color - of line, e.g. 'r', for red
%
% last modified by terd 05.01.2008

figure
set(gca,'FontSize',12);
[porti,portj,Nfreqs]=size(Matrix);
m=1;
   for n=1:porti
       for o=1:portj
            set(gca,'FontSize',8);
            subplot(porti,portj,m);
            dummy=squeeze(Matrix(n,o,:));
            plot(freq./1e9,20*log10((abs(dummy))),'Color',color);
            hold on;
            grid on;
            xlabel('frequency [GHz]');
            ylabel('S-parameters [dB]');
            m=1+m;
       end;
   end;
hold off;
grid on;


