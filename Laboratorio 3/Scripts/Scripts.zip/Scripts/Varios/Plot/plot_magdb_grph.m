function plot_magdb_grph(Matrix,freq,color,Vector1,freq1,color1)

% This function plots the magnitude in dB scale of a parameter against the frequency
% Inputs:
%       Matrix - e.g. SAB(1,1,:)
%       freq -  frequency vector
%       color - of line, e.g. 'r', for red
%       Vector1 - 2 dimension vector with values.
%       freq1 - 2 dimension vector with frequency.

% This function allows the comparition of plot of two different text files
% with extension: (*.snp ,% *.ts) and (*.txt); 
% and generates the S-paramaters and the frequency vector.

% Consider that both files must be previously imported into the workspace
% before using this function.

% Written by Robert Barnes on Sep 2015.
%

%figure

set(gca,'FontSize',20);
dummy=squeeze(Matrix);
plot(freq./1e9,20*log10((abs(dummy))),'Color',color,'LineWidth',3);
hold on;
grid on;
plot(freq1,Vector1,'Color',color1,'LineWidth',3);
hold off;
xlabel('Frequency [GHz]');
ylabel('S-parameters [dB]');
