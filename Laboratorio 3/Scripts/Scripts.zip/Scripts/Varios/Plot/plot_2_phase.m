function plot_2_phase(Matrix,freq,color,Matrix1,freq1,color1)

% This function plots the phase of 2 parameters against the frequency
% Inputs:
%       Matrix - first parameter e.g. SAB(1,1,:)
%       freq -  first frequency vector
%       color - of first line, e.g. 'r', for red
%       Matrix1 - second parameter e.g. SAB(1,2,:)
%       freq1 -  second frequency vector
%       color1 - of second line, e.g. 'r', for red
%
% last modified by terd 05.01.2008

figure
set(gca,'FontSize',12);
dummy=squeeze(Matrix);
plot(freq./1e9,angle(dummy),'Color',color);
hold on;
grid on;
dummy=squeeze(Matrix1);
plot(freq1./1e9,angle(dummy),'Color',color1);
hold off;

xlabel('frequency [GHz]');
ylabel('S-Parameters Phase [rad]');

