% Graficos de Fase a partir de Par�metros S
% Instituto Tecnologico de Costa Rica (www.tec.ac.cr)
% Escuela de Ingenier�a Electr�nica
% Prof: Ing. Sergio Arriola-Valverde. M. Sc (sarriola@tec.ac.cr)
% Curso: EL-5522 Taller de Comunicaciones El�ctricas
% Este Script esta estructurado en Matlab 
% Prop�sito General: Grafico de Fase a partir de Par�metros S
% Entradas: Touchstone files
% Este material son para uso unicamente didactico y academico

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Limpio la terminal y variables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc;
close all;
clear all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Busqueda de archivos snp
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[Nombre_Arch, Dir_Arch] = uigetfile( ...
{'*.s1p;*.s2p;*.s3p;*.s4p;*.s5p;*.s6p;*.s7p;*.s8p;*.s9p;*.s10p;*.s12p;*.ts',...
 'Touchstone Files (*.snp,*.ts)';
   '*.snp', 'Version 1.0 (*.s1p;*.s2p;*.s3p;*.s4p;*.s5p;*.s6p;*.s7p;*.s8p;*.s9p;*.s10p;*.s12p)'; ...
   '*.ts', 'Version 2.0 (*.ts)'
   '*.*',  'All Files (*.*)'}, ...
   'Select a file');
data = read(rfdata.data,Nombre_Arch);
frecs = data.Freq;
frecs=frecs'; % Vector de frecuencuas
ZF = extract(data,'S_PARAMETERS'); % Matriz de parametros
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Grafica de parametros S
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
set(gca,'FontSize',12);
dummy=squeeze(ZF(1,2,:));
plot(frecs./1e9,angle(dummy).*(180/pi),'Color','r','LineWidth',3);
hold on;
grid on;
ax = gca;
ax.FontSize = 13;
legend({'Fase (�)'},'Location','southeast')
xlabel('Frecuencia [GHz]');
ylabel('Fase (�)');




